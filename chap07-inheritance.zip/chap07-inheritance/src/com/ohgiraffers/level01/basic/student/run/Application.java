package com.ohgiraffers.level01.basic.student.run;

import com.ohgiraffers.level01.basic.student.model.dto.StudentDTO;

import java.util.Scanner;

public class Application {
    public static void main(String[] args) {
        // 최대 10명의 학생 정보를 기록할 수 있게
        // 객체 배열을 할당하고
        // 반복문을 사용하여 키보드로 학생 정보를
        // 입력 받도록 구현
        // 3명의 학생 정보를 입력 받아, 각 객체에
        // 저장, 현재 기록된 학생들의 정보와 각 학
        // 생의 평균 점수를 출력

        // 최대 10명의 학생 정보를 기록할 수 있게 배열을 할당한다.
        // while문을 사용하여 학생들의 정보를 계속 입력 받고
        // 한 명씩 추가 될 때마다 카운트함
        // 계속 추가할 것인지 물어보고, 대소문자 상관없이 ‘y’이면 계속 객체 추가
        // 3명 정도의 학생 정보를 입력 받아 각 객체에 저장함
        // 현재 기록된 학생들의 각각의 점수 평균을 구함
        // 학생들의 정보를 모두 출력 (평균 포함)

//        **힌트 :**  ‘y’ 대소문자 상관없이 입력받는 것
//
//        1. toUpperCase().charAt() 활용 또는
//        2.  equalsIgnoreCase() 활용

        StudentDTO studentDTO = new StudentDTO();

        Scanner sc = new Scanner(System.in);

        StudentDTO[] arr = new StudentDTO[10];

        boolean fact = true;

        int h = 0;

        while (fact){
            System.out.println("학년 : ");
            int a = Integer.parseInt(sc.nextLine());

            System.out.println("반 : ");
            int b = Integer.parseInt(sc.nextLine());

            System.out.println("이름 : ");
            String c = sc.nextLine();

            System.out.println("국어점수 : ");
            int d = Integer.parseInt(sc.nextLine());

            System.out.println("영어점수 : ");
            int e = Integer.parseInt(sc.nextLine());

            System.out.println("수학점수 : ");
            int f = Integer.parseInt(sc.nextLine());

            System.out.println("계속 추가할 겁니까 ? (y/n) :");
            String g = sc.nextLine();

            charAt(g-'0');

            if (g = 0;){

            }
            h++;

        }

    }
}
